# Contributing 

Welcome, and thank you for your interest in contributing. There are many ways to contribute: 
* [Submit issues](https://github.com/marykolade/Social-Media-Analytics-Facebook/issues) to report bugs and make suggestions. 
* Review the [source code changes](https://github.com/marykolade/Social-Media-Analytics-Facebook/compare). 
* Contribute features and fixes by forking the repository and creating a [pull request](https://github.com/Social-Media-Analytics-Facebook/pulls). 

